@echo off
cd /d "%~dp0"
python substring_finder.py
if errorlevel 1 pause
