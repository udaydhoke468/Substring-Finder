"""Substring Finder: native Windows desktop app (Tkinter, no extra packages)."""
from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk

BG = "#0b1020"
PANEL = "#121a2d"
TEXT = "#eff4ff"
MUTED = "#91a0ba"
ACCENT = "#8b9cff"
GREEN = "#43d9a3"


def simulate(pattern: str, text: str) -> dict:
    if not pattern:
        raise ValueError("Pattern khali nahi ho sakta.")
    alphabet = sorted(set(pattern))
    m = len(pattern)
    transitions = {}
    for q in range(m):
        for char in alphabet:
            candidate = pattern[:q] + char
            k = min(m, len(candidate))
            while k and candidate[-k:] != pattern[:k]:
                k -= 1
            transitions[q, char] = k
    overlap = m - 1
    while overlap and pattern[-overlap:] != pattern[:overlap]:
        overlap -= 1
    state = count = 0
    matches, trace = [], []
    for index, char in enumerate(text):
        old = state
        state = transitions[old, char] if char in alphabet else 0
        found = state == m
        if found:
            count += 1
            matches.append(index)
            state = overlap
        trace.append((index + 1, char, old, state, "Match!" if found else "—", count))
    table = [(q, char, transitions[q, char]) for q in range(m) for char in alphabet]
    return {"count": count, "matches": matches, "final": state, "trace": trace, "transitions": table}


class SubstringFinderApp:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Substring Finder — DFA Simulator")
        self.root.geometry("1000x760")
        self.root.minsize(760, 600)
        self.root.configure(bg=BG)
        self.result = None
        self.step = 0
        self.after_id = None
        self._style()
        self._build()
        self.run()

    def _style(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure("Treeview", background="#0b1222", foreground=TEXT, fieldbackground="#0b1222", rowheight=27)
        style.configure("Treeview.Heading", background="#18233a", foreground=TEXT, font=("Segoe UI", 9, "bold"))
        style.map("Treeview", background=[("selected", "#30466a")], foreground=[("selected", TEXT)])

    def _label(self, parent, text, size=10, color=TEXT, bold=False):
        return tk.Label(parent, text=text, bg=parent["bg"], fg=color, font=("Segoe UI", size, "bold" if bold else "normal"))

    def _build(self):
        outer = tk.Frame(self.root, bg=BG, padx=22, pady=18)
        outer.pack(fill="both", expand=True)
        self._label(outer, "FINITE AUTOMATA · STREAMING STRING MATCH", 9, GREEN, True).pack(anchor="w")
        self._label(outer, "Substring Finder", 24, TEXT, True).pack(anchor="w", pady=(4, 2))
        self._label(outer, "Count every occurrence, including overlapping matches, and step through the DFA.", 10, MUTED).pack(anchor="w", pady=(0, 14))

        inputs = tk.Frame(outer, bg=PANEL, padx=16, pady=14)
        inputs.pack(fill="x")
        self._label(inputs, "Numeric pattern", 10, TEXT, True).pack(anchor="w")
        self.pattern = tk.Entry(inputs, font=("Consolas", 12), bg="#0b1222", fg=TEXT, insertbackground=TEXT, relief="flat")
        self.pattern.insert(0, "1011")
        self.pattern.pack(fill="x", ipady=8, pady=(5, 12))
        self._label(inputs, "Text stream", 10, TEXT, True).pack(anchor="w")
        self.stream = tk.Text(inputs, height=4, wrap="word", font=("Consolas", 11), bg="#0b1222", fg=TEXT, insertbackground=TEXT, relief="flat")
        self.stream.insert("1.0", "1011011")
        self.stream.pack(fill="x", pady=(5, 10))
        buttons = tk.Frame(inputs, bg=PANEL)
        buttons.pack(anchor="w")
        self._button(buttons, "Run DFA simulation", self.run, primary=True).pack(side="left", padx=(0, 7))
        self._button(buttons, "Load example", self.load_example).pack(side="left", padx=7)
        self._button(buttons, "Reset / clear", self.reset).pack(side="left", padx=7)

        result = tk.Frame(outer, bg=PANEL, padx=16, pady=12)
        result.pack(fill="x", pady=12)
        self.result_label = self._label(result, "Occurrences: —     Final DFA state: —", 13, GREEN, True)
        self.result_label.pack(anchor="w")
        self.matches_label = self._label(result, "Match start positions (1-based): —", 10, TEXT)
        self.matches_label.pack(anchor="w", pady=(5, 0))

        self._label(outer, "DFA transitions", 11, TEXT, True).pack(anchor="w", pady=(3, 5))
        self.transitions = tk.Text(outer, height=5, bg="#0b1222", fg=TEXT, font=("Consolas", 10), relief="flat", state="disabled")
        self.transitions.pack(fill="x")

        trace_header = tk.Frame(outer, bg=BG)
        trace_header.pack(fill="x", pady=(11, 5))
        self._label(trace_header, "Stream trace", 11, TEXT, True).pack(side="left")
        controls = tk.Frame(trace_header, bg=BG)
        controls.pack(side="right")
        self.start_button = self._button(controls, "⏮ Start", lambda: self.move(-self.step))
        self.start_button.pack(side="left", padx=3)
        self.previous_button = self._button(controls, "← Previous", lambda: self.move(-1))
        self.previous_button.pack(side="left", padx=3)
        self.play_button = self._button(controls, "▶ Play", self.toggle_play, primary=True)
        self.play_button.pack(side="left", padx=3)
        self.next_button = self._button(controls, "Next →", lambda: self.move(1))
        self.next_button.pack(side="left", padx=3)
        self.status = self._label(outer, "Run simulation to enable step controls.", 9, MUTED)
        self.status.pack(anchor="w", pady=(0, 5))
        columns = ("pos", "char", "from", "to", "event", "count")
        self.trace = ttk.Treeview(outer, columns=columns, show="headings", height=8)
        for key, title, width in [("pos", "Position", 90), ("char", "Input", 90), ("from", "From", 90), ("to", "To", 90), ("event", "Event", 110), ("count", "Count", 90)]:
            self.trace.heading(key, text=title)
            self.trace.column(key, width=width, anchor="center")
        self.trace.pack(fill="both", expand=True)

    def _button(self, parent, label, command, primary=False):
        return tk.Button(parent, text=label, command=command, bg=ACCENT if primary else "#24314c", fg="#10152a" if primary else TEXT,
                         activebackground="#a9b3ff", activeforeground="#10152a", relief="flat", padx=12, pady=7,
                         font=("Segoe UI", 9, "bold"), cursor="hand2")

    def _set_disabled(self, enabled):
        state = "normal" if enabled else "disabled"
        for button in (self.start_button, self.previous_button, self.play_button, self.next_button):
            button.configure(state=state)

    def run(self):
        self.stop_play()
        try:
            self.result = simulate(self.pattern.get(), self.stream.get("1.0", "end-1c"))
        except ValueError as exc:
            self.reset_result()
            messagebox.showerror("Pattern error", str(exc), parent=self.root)
            return
        self.step = 0
        data = self.result
        self.result_label.config(text=f"Occurrences: {data['count']}     Final DFA state: q{data['final']}")
        positions = ", ".join(str(i + 1) for i in data["matches"]) or "No matches"
        self.matches_label.config(text=f"Match start positions (1-based): {positions}")
        lines = ["Current state   Input   Next state"]
        lines.extend(f"q{q:<14} {char!r:<7} q{n}{' (accept)' if n == len(self.pattern.get()) else ''}" for q, char, n in data["transitions"])
        self.transitions.configure(state="normal")
        self.transitions.delete("1.0", "end")
        self.transitions.insert("1.0", "\n".join(lines))
        self.transitions.configure(state="disabled")
        self.trace.delete(*self.trace.get_children())
        for row in data["trace"]:
            self.trace.insert("", "end", iid=str(row[0] - 1), values=row)
        self._set_disabled(bool(data["trace"]))
        self.render_step()

    def render_step(self):
        if not self.result:
            return
        trace = self.result["trace"]
        state = 0 if self.step == 0 else trace[self.step - 1][3]
        count = 0 if self.step == 0 else trace[self.step - 1][5]
        self.status.config(text=f"Step {self.step} / {len(trace)} · state q{state} · matches so far {count}")
        self.start_button.configure(state="disabled" if self.step == 0 or not trace else "normal")
        self.previous_button.configure(state="disabled" if self.step == 0 or not trace else "normal")
        self.next_button.configure(state="disabled" if self.step >= len(trace) or not trace else "normal")
        self.play_button.configure(state="normal" if trace else "disabled")
        if self.step:
            iid = str(self.step - 1)
            self.trace.selection_set(iid)
            self.trace.see(iid)
        else:
            self.trace.selection_remove(self.trace.selection())

    def move(self, amount):
        if not self.result:
            return
        self.step = max(0, min(len(self.result["trace"]), self.step + amount))
        self.render_step()

    def toggle_play(self):
        if self.after_id:
            self.stop_play()
            return
        if not self.result or not self.result["trace"]:
            return
        if self.step >= len(self.result["trace"]):
            self.step = 0
        self.play_button.configure(text="⏸ Pause")
        self.play_tick()

    def play_tick(self):
        if not self.result:
            self.stop_play()
            return
        if self.step >= len(self.result["trace"]):
            self.stop_play()
            return
        self.step += 1
        self.render_step()
        if self.step < len(self.result["trace"]):
            self.after_id = self.root.after(500, self.play_tick)
        else:
            self.after_id = None
            self.play_button.configure(text="▶ Play")

    def stop_play(self):
        if self.after_id:
            self.root.after_cancel(self.after_id)
            self.after_id = None
        if hasattr(self, "play_button"):
            self.play_button.configure(text="▶ Play")

    def reset_result(self):
        self.result = None
        self.step = 0
        self.result_label.config(text="Occurrences: —     Final DFA state: —")
        self.matches_label.config(text="Match start positions (1-based): —")
        self.transitions.configure(state="normal")
        self.transitions.delete("1.0", "end")
        self.transitions.configure(state="disabled")
        self.trace.delete(*self.trace.get_children())
        self.status.config(text="Run simulation to enable step controls.")
        self._set_disabled(False)

    def reset(self):
        self.stop_play()
        self.pattern.delete(0, "end")
        self.stream.delete("1.0", "end")
        self.reset_result()

    def load_example(self):
        self.stop_play()
        self.pattern.delete(0, "end")
        self.pattern.insert(0, "1011")
        self.stream.delete("1.0", "end")
        self.stream.insert("1.0", "1011011")
        self.run()


if __name__ == "__main__":
    root = tk.Tk()
    SubstringFinderApp(root)
    root.mainloop()
