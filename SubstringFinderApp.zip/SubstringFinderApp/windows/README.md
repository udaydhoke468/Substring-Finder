# Windows desktop build

Run from this folder:

```powershell
python substring_finder.py
```

Or double-click `run_windows.bat`.

## Optional standalone EXE

Install PyInstaller once and build the executable:

```powershell
python -m pip install pyinstaller
pyinstaller --onefile --windowed --name SubstringFinder substring_finder.py
```

The executable is created in `dist\SubstringFinder.exe`.
