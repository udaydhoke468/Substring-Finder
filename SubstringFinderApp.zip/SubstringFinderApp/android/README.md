# Android build

1. Install Android Studio with Android SDK Platform 36 and JDK 17.
2. Open this `android` folder as a project.
3. Wait for Gradle sync, select an emulator or connected phone, and press **Run**.
4. To create a debug APK, use **Build > Build APK(s)**. Android Studio places it under `app/build/outputs/apk/debug/`.

The app is native Java and computes matches on the device; it needs no network permission or third-party libraries. Build configuration uses AGP 9.4.0 / Gradle 9.6.0.
