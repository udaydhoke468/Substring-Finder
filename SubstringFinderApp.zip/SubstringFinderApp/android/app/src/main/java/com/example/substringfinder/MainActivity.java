package com.example.substringfinder;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(11, 16, 32);
    private static final int PANEL = Color.rgb(18, 26, 45);
    private static final int INPUT_BG = Color.rgb(11, 18, 34);
    private static final int FG = Color.rgb(239, 244, 255);
    private static final int MUTED = Color.rgb(145, 160, 186);
    private static final int ACCENT = Color.rgb(139, 156, 255);
    private static final int GREEN = Color.rgb(67, 217, 163);

    private final Handler handler = new Handler(Looper.getMainLooper());
    private EditText patternInput;
    private EditText streamInput;
    private TextView resultView;
    private TextView matchesView;
    private TextView transitionView;
    private TextView traceView;
    private TextView stepView;
    private Button startButton, previousButton, playButton, nextButton;
    private List<String> traceRows = new ArrayList<>();
    private List<Integer> traceStates = new ArrayList<>();
    private List<Integer> traceCounts = new ArrayList<>();
    private int finalState = 0;
    private int matchCount = 0;
    private int step = 0;
    private boolean playing = false;

    private final Runnable playTick = new Runnable() {
        @Override public void run() {
            if (!playing || traceRows.isEmpty()) return;
            if (step < traceRows.size()) step++;
            renderStep();
            if (step < traceRows.size()) handler.postDelayed(this, 500);
            else {
                playing = false;
                playButton.setText("Play");
                renderStep();
            }
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(BG);
        window.setNavigationBarColor(BG);
        buildUi();
        runSimulation();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout page = column(BG);
        page.setPadding(dp(20), dp(22), dp(20), dp(28));
        scroll.addView(page);

        TextView eyebrow = label("FINITE AUTOMATA · STRING MATCH", 12, GREEN, true);
        page.addView(eyebrow);
        TextView title = label("Substring Finder", 30, FG, true);
        title.setPadding(0, dp(5), 0, dp(2));
        page.addView(title);
        page.addView(label("Count every match, including overlaps, and step through the DFA.", 14, MUTED, false));

        LinearLayout inputCard = column(PANEL);
        inputCard.setPadding(dp(16), dp(15), dp(16), dp(16));
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.topMargin = dp(18);
        page.addView(inputCard, cardParams);
        inputCard.addView(label("Numeric pattern", 14, FG, true));
        patternInput = input("1011", false);
        LinearLayout.LayoutParams fieldParams = new LinearLayout.LayoutParams(-1, -2);
        fieldParams.topMargin = dp(6);
        fieldParams.bottomMargin = dp(13);
        inputCard.addView(patternInput, fieldParams);
        inputCard.addView(label("Text stream", 14, FG, true));
        streamInput = input("1011011", true);
        fieldParams = new LinearLayout.LayoutParams(-1, -2);
        fieldParams.topMargin = dp(6);
        fieldParams.bottomMargin = dp(13);
        inputCard.addView(streamInput, fieldParams);
        LinearLayout actions = row();
        inputCard.addView(actions);
        addButton(actions, "Run", ACCENT, this::runSimulation, 1f);
        addButton(actions, "Example", Color.rgb(36, 49, 76), this::loadExample, 1f);
        addButton(actions, "Reset", Color.rgb(36, 49, 76), this::reset, 1f);

        LinearLayout results = column(PANEL);
        results.setPadding(dp(16), dp(13), dp(16), dp(13));
        cardParams = new LinearLayout.LayoutParams(-1, -2);
        cardParams.topMargin = dp(12);
        page.addView(results, cardParams);
        resultView = label("Occurrences: —     Final state: —", 17, GREEN, true);
        results.addView(resultView);
        matchesView = label("Match start positions (1-based): —", 13, FG, false);
        LinearLayout.LayoutParams resultParam = new LinearLayout.LayoutParams(-1, -2);
        resultParam.topMargin = dp(6);
        results.addView(matchesView, resultParam);

        addSectionLabel(page, "DFA transitions");
        transitionView = monoBox();
        page.addView(transitionView, boxParams());

        addSectionLabel(page, "Stream trace");
        LinearLayout controls = row();
        page.addView(controls);
        startButton = addButton(controls, "|<", Color.rgb(36, 49, 76), () -> moveTo(0), 1f);
        previousButton = addButton(controls, "Previous", Color.rgb(36, 49, 76), () -> moveBy(-1), 1.3f);
        playButton = addButton(controls, "Play", ACCENT, this::togglePlay, 1f);
        nextButton = addButton(controls, "Next", Color.rgb(36, 49, 76), () -> moveBy(1), 1f);
        stepView = label("Run simulation to enable step controls.", 12, MUTED, false);
        LinearLayout.LayoutParams stepParams = new LinearLayout.LayoutParams(-1, -2);
        stepParams.topMargin = dp(6);
        stepParams.bottomMargin = dp(6);
        page.addView(stepView, stepParams);
        traceView = monoBox();
        page.addView(traceView, boxParams());
        setContentView(scroll);
        setStepControls(false);
    }

    private LinearLayout column(int color) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(color);
        return layout;
    }

    private LinearLayout row() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.HORIZONTAL);
        layout.setGravity(Gravity.CENTER_VERTICAL);
        return layout;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextSize(size);
        view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private EditText input(String value, boolean multiLine) {
        EditText edit = new EditText(this);
        edit.setText(value);
        edit.setTextColor(FG);
        edit.setHintTextColor(MUTED);
        edit.setTextSize(16);
        edit.setSingleLine(!multiLine);
        edit.setInputType(multiLine
                ? InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                : InputType.TYPE_CLASS_TEXT);
        edit.setGravity(multiLine ? Gravity.TOP | Gravity.START : Gravity.CENTER_VERTICAL);
        edit.setPadding(dp(12), dp(10), dp(12), dp(10));
        edit.setBackgroundColor(INPUT_BG);
        if (multiLine) edit.setMinLines(4);
        return edit;
    }

    private TextView monoBox() {
        TextView view = label("", 12, FG, false);
        view.setTypeface(Typeface.MONOSPACE);
        view.setBackgroundColor(INPUT_BG);
        view.setPadding(dp(12), dp(10), dp(12), dp(10));
        return view;
    }

    private LinearLayout.LayoutParams boxParams() {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.bottomMargin = dp(12);
        return params;
    }

    private void addSectionLabel(LinearLayout page, String text) {
        TextView label = label(text, 15, FG, true);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(14);
        params.bottomMargin = dp(6);
        page.addView(label, params);
    }

    private Button addButton(LinearLayout parent, String text, int color, Runnable action, float weight) {
        Button button = new Button(this);
        button.setText(text);
        button.setAllCaps(false);
        button.setTextSize(12);
        button.setTextColor(color == ACCENT ? BG : FG);
        button.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        button.setOnClickListener(view -> action.run());
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(0, dp(46), weight);
        params.setMargins(dp(2), dp(2), dp(2), dp(2));
        parent.addView(button, params);
        return button;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private int transition(String pattern, int state, char input) {
        String candidate = pattern.substring(0, state) + input;
        int next = Math.min(pattern.length(), candidate.length());
        while (next > 0 && !candidate.endsWith(pattern.substring(0, next))) next--;
        return next;
    }

    private void runSimulation() {
        stopPlay();
        String pattern = patternInput.getText().toString();
        String text = streamInput.getText().toString();
        if (pattern.isEmpty()) {
            Toast.makeText(this, "Pattern khali nahi ho sakta.", Toast.LENGTH_SHORT).show();
            return;
        }
        TreeSet<Character> alphabet = new TreeSet<>();
        for (char c : pattern.toCharArray()) alphabet.add(c);
        StringBuilder transitions = new StringBuilder("State   Input   Next state\n");
        for (int q = 0; q < pattern.length(); q++) {
            for (char c : alphabet) {
                int next = transition(pattern, q, c);
                transitions.append("q").append(q).append("      '").append(c).append("'      q").append(next);
                if (next == pattern.length()) transitions.append(" (accept)");
                transitions.append('\n');
            }
        }
        transitionView.setText(transitions.toString());
        int overlap = pattern.length() - 1;
        while (overlap > 0 && !pattern.substring(pattern.length() - overlap).equals(pattern.substring(0, overlap))) overlap--;
        int state = 0, count = 0;
        List<Integer> matches = new ArrayList<>();
        traceRows = new ArrayList<>();
        traceStates = new ArrayList<>();
        traceCounts = new ArrayList<>();
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            int from = state;
            state = alphabet.contains(c) ? transition(pattern, state, c) : 0;
            boolean found = state == pattern.length();
            if (found) {
                count++;
                matches.add(i - pattern.length() + 1);
                state = overlap;
            }
            traceRows.add(String.format("%3d   %s   q%d   q%d   %-7s   %d", i + 1, printable(c), from, state, found ? "Match!" : "—", count));
            traceStates.add(state);
            traceCounts.add(count);
        }
        finalState = state;
        matchCount = count;
        step = 0;
        resultView.setText("Occurrences: " + count + "     Final state: q" + finalState);
        StringBuilder positions = new StringBuilder("Match start positions (1-based): ");
        if (matches.isEmpty()) positions.append("No matches");
        else for (int i = 0; i < matches.size(); i++) {
            if (i > 0) positions.append(", ");
            positions.append(matches.get(i) + 1);
        }
        matchesView.setText(positions.toString());
        setStepControls(!traceRows.isEmpty());
        renderStep();
    }

    private String printable(char c) {
        return Character.isWhitespace(c) ? "[space]" : String.valueOf(c);
    }

    private void renderStep() {
        int state = step == 0 ? 0 : traceStates.get(step - 1);
        int count = step == 0 ? 0 : traceCounts.get(step - 1);
        stepView.setText("Step " + step + " / " + traceRows.size() + " · state q" + state + " · matches so far " + count);
        StringBuilder display = new StringBuilder("Pos   Char   From   To   Event   Count\n");
        for (int i = 0; i < traceRows.size(); i++) {
            display.append(i == step - 1 ? "▶ " : i < step ? "✓ " : "  ").append(traceRows.get(i)).append('\n');
        }
        traceView.setText(display.toString());
        startButton.setEnabled(step > 0);
        previousButton.setEnabled(step > 0);
        nextButton.setEnabled(step < traceRows.size());
        playButton.setEnabled(!traceRows.isEmpty());
    }

    private void setStepControls(boolean enabled) {
        startButton.setEnabled(enabled);
        previousButton.setEnabled(enabled);
        nextButton.setEnabled(enabled);
        playButton.setEnabled(enabled);
    }

    private void moveTo(int destination) {
        stopPlay();
        step = destination;
        renderStep();
    }

    private void moveBy(int delta) {
        stopPlay();
        step = Math.max(0, Math.min(traceRows.size(), step + delta));
        renderStep();
    }

    private void togglePlay() {
        if (playing) {
            stopPlay();
            return;
        }
        if (traceRows.isEmpty()) return;
        if (step >= traceRows.size()) step = 0;
        playing = true;
        playButton.setText("Pause");
        handler.post(playTick);
    }

    private void stopPlay() {
        playing = false;
        handler.removeCallbacks(playTick);
        if (playButton != null) playButton.setText("Play");
    }

    private void loadExample() {
        patternInput.setText("1011");
        streamInput.setText("1011011");
        runSimulation();
    }

    private void reset() {
        stopPlay();
        patternInput.setText("");
        streamInput.setText("");
        resultView.setText("Occurrences: —     Final state: —");
        matchesView.setText("Match start positions (1-based): —");
        transitionView.setText("");
        traceView.setText("");
        stepView.setText("Run simulation to enable step controls.");
        traceRows.clear();
        traceStates.clear();
        traceCounts.clear();
        finalState = 0;
        matchCount = 0;
        step = 0;
        setStepControls(false);
    }

    @Override protected void onDestroy() {
        stopPlay();
        super.onDestroy();
    }
}
