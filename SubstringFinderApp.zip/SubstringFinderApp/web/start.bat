@echo off
cd /d "%~dp0"
echo Starting Substring Finder...
python server.py
if errorlevel 1 (
  echo.
  echo Server start nahi hua. Python 3 install karein aur PATH mein add karein.
  pause
)
