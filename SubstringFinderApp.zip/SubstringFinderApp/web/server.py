from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
import webbrowser


ROOT = Path(__file__).resolve().parent


def simulate(pattern: str, text: str) -> dict:
    if not isinstance(pattern, str) or not pattern:
        raise ValueError("Pattern khali nahi ho sakta.")
    if not isinstance(text, str):
        raise ValueError("Text string hona chahiye.")

    alphabet = sorted(set(pattern))
    m = len(pattern)
    # State q is the longest suffix of processed input that is a prefix of pattern.
    transitions: dict[tuple[int, str], int] = {}
    for q in range(m):
        for char in alphabet:
            candidate = pattern[:q] + char
            k = min(m, len(candidate))
            while k and candidate[-k:] != pattern[:k]:
                k -= 1
            transitions[q, char] = k

    overlap = m - 1
    while overlap and pattern[-overlap:] != pattern[:overlap]:
        overlap -= 1

    state = 0
    count = 0
    matches: list[int] = []  # zero-based start offsets
    trace = []
    for index, char in enumerate(text):
        old = state
        state = transitions[old, char] if char in alphabet else 0
        found = state == m
        if found:
            count += 1
            matches.append(index - m + 1)
            state = overlap  # accepting transition falls back for overlapping matches
        trace.append({
            "index": index,
            "char": char,
            "from": old,
            "to": state,
            "match": found,
            "count": count,
        })

    return {
        "pattern": pattern,
        "text": text,
        "count": count,
        "matches": matches,
        "final_state": state,
        "states": list(range(m)),
        "alphabet": alphabet,
        "transitions": [
            {"state": q, "char": char, "next": transitions[q, char]}
            for q in range(m) for char in alphabet
        ],
        "trace": trace,
    }


class Handler(BaseHTTPRequestHandler):
    def _send(self, status: int, payload: bytes, content_type: str) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path in ("/", "/index.html"):
            self._send(200, (ROOT / "index.html").read_bytes(), "text/html; charset=utf-8")
        elif path == "/api/health":
            self._send(200, b'{"status":"ok"}', "application/json; charset=utf-8")
        else:
            self._send(404, b'{"error":"Not found"}', "application/json; charset=utf-8")

    def do_POST(self) -> None:
        if urlparse(self.path).path != "/api/simulate":
            self._send(404, b'{"error":"Not found"}', "application/json; charset=utf-8")
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length > 2_000_000:
                raise ValueError("Request bahut bada hai (2 MB limit).")
            payload = json.loads(self.rfile.read(length))
            result = simulate(payload.get("pattern"), payload.get("text"))
            self._send(200, json.dumps(result, ensure_ascii=False).encode(), "application/json; charset=utf-8")
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            self._send(400, json.dumps({"error": str(exc)}, ensure_ascii=False).encode(), "application/json; charset=utf-8")

    def log_message(self, fmt: str, *args) -> None:
        print(f"[{self.log_date_time_string()}] {fmt % args}")


if __name__ == "__main__":
    host, port = "127.0.0.1", 8000
    server = ThreadingHTTPServer((host, port), Handler)
    url = f"http://{host}:{port}"
    print(f"Substring Finder running at {url}")
    print("Is terminal ko khula rakhein. Band karne ke liye Ctrl+C dabayein.")
    webbrowser.open(url)
    server.serve_forever()
